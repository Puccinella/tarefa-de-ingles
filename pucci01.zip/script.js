const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const backgroundImage = new Image();
backgroundImage.src = "background.png"; // Coloque o caminho da sua imagem de fundo

const spaceshipImage = new Image();
spaceshipImage.src = "nave.png"; // Coloque o caminho da sua imagem de nave

canvas.width = 900;
canvas.height = window.innerHeight;

let words = [];
let score = 0;
let activeWord = null;
const usedWords = new Set(); // ⛔ impede repetição no dicionário

// Lista de palavras
const wordList = [
  "cpu", "click", "gadgets", "software", "mouse", "object", "internet", "function", "hardware",
  "keyboard", "monitor", "cloud", "server", "network", "device", "variable", "loop",
  "array", "input", "output", "debug", "compile", "router", "screen", "mobile", "access",
  "frame", "binary", "cursor", "pixel", "domain", "syntax", "code", "cache", "logic"
];

// Traduções
const translations = {
  cpu: "unidade central de processamento",
  click: "clique",
  gadgets: "dispositivos",
  software: "programa de computador",
  mouse: "mouse",
  object: "objeto",
  internet: "internet",
  function: "função",
  hardware: "hardware",
  keyboard: "teclado",
  monitor: "monitor",
  cloud: "nuvem",
  server: "servidor",
  network: "rede",
  device: "dispositivo",
  variable: "variável",
  loop: "laço",
  array: "vetor",
  input: "entrada",
  output: "saída",
  debug: "depurar",
  compile: "compilar",
  router: "roteador",
  screen: "tela",
  mobile: "celular",
  access: "acesso",
  frame: "quadro",
  binary: "binário",
  cursor: "cursor",
  pixel: "pixel",
  domain: "domínio",
  syntax: "sintaxe",
  code: "código",
  cache: "cache",
  logic: "lógica"
};

let backgroundY = 0; // Posição inicial do fundo

function getRandomWord() {
  return wordList[Math.floor(Math.random() * wordList.length)];
}

function spawnWord() {
  const word = {
    text: getRandomWord(),
    x: Math.random() * (canvas.width - 100),
    y: 0,
    speed: 1 + Math.random() * 1.5,
    progress: 0
  };
  words.push(word);
}

function updateWords() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Desenha o fundo movendo-o
  ctx.drawImage(backgroundImage, 0, backgroundY, canvas.width, canvas.height); // Fundo superior
  ctx.drawImage(backgroundImage, 0, backgroundY - canvas.height, canvas.width, canvas.height); // Fundo inferior (justificado com o topo)

  // Atualiza a posição do fundo para criar o movimento
  backgroundY += 1; // Velocidade do movimento do fundo
  if (backgroundY >= canvas.height) {
    backgroundY = 0; // Reinicia a posição quando o fundo passa completamente
  }

  // Desenha a nave
  if (spaceshipImage.complete) {
    const spaceshipX = canvas.width / 2 - spaceshipImage.width / 2; // Centraliza a nave
    const spaceshipY = canvas.height - spaceshipImage.height - 20; // Coloca a nave no fundo
    ctx.drawImage(spaceshipImage, spaceshipX, spaceshipY);
  }

  ctx.font = "24px Courier New";

  for (let i = words.length - 1; i >= 0; i--) {
    const word = words[i];
    word.y += word.speed;

    ctx.fillStyle = "lime";
    ctx.fillText(word.text.substring(0, word.progress), word.x, word.y);

    ctx.fillStyle = "white";
    ctx.fillText(
      word.text.substring(word.progress),
      word.x + ctx.measureText(word.text.substring(0, word.progress)).width,
      word.y
    );

    if (word.y > canvas.height) {
      words.splice(i, 1);
      if (activeWord === word) activeWord = null;
      score -= 20;
      document.getElementById("score").textContent = "Pontos: " + score;
    }
  }
}

function handleKeyPress(e) {
  const char = e.key.toLowerCase();

  if (!activeWord) {
    activeWord = words.find(w => w.text.startsWith(char));
    if (activeWord) activeWord.progress = 1;
  } else {
    const expectedChar = activeWord.text[activeWord.progress];
    if (char === expectedChar) {
      activeWord.progress++;

      if (activeWord.progress === activeWord.text.length) {
        words = words.filter(w => w !== activeWord);
        score += 10;
        document.getElementById("score").textContent = "Pontos: " + score;

        // ✅ Adiciona ao dicionário se ainda não tiver sido usado
        const word = activeWord.text;
        if (!usedWords.has(word)) {
          usedWords.add(word);
          const li = document.createElement("li");
          li.textContent = `${word} → ${translations[word] || "tradução não encontrada"}`;
          document.getElementById("dictionaryList").appendChild(li);
        }

        activeWord = null;
      }
    }
  }
}

setInterval(spawnWord, 2000);

function gameLoop() {
  updateWords();
  requestAnimationFrame(gameLoop);
}

window.addEventListener("keydown", handleKeyPress);
gameLoop();
